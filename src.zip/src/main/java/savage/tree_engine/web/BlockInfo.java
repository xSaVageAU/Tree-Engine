package savage.tree_engine.web;

public class BlockInfo {
    public int x;
    public int y;
    public int z;
    public String block;

    public BlockInfo(int x, int y, int z, String block) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.block = block;
    }
}
