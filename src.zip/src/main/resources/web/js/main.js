// Main entry point for the application

window.addEventListener('DOMContentLoaded', () => {
    initBabylon();
    setupUI();
    // Initial load handled by tree browser
});